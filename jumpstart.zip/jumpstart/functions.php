<?php
/*-----------------------------------------------------------------------------------*/
/* Run Theme Blvd Framework
/*
/* Below is the file needed to load the parent theme and theme framework.
/* It's included with require_once().
/*
/* If you're creating a child theme, this line needs to be at the top of your
/* child theme's functions.php. By doing this you're overriding the file being
/* included here.
/*-----------------------------------------------------------------------------------*/

require_once( get_template_directory() . '/framework/themeblvd.php' );
add_filter( 'gform_enable_field_label_visibility_settings', '__return_true' );