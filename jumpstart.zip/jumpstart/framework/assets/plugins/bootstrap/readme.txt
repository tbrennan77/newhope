When compiling Bootstrap, make sure uncheck “Glyphicons”

And only keep following files:
/css/bootstrap.min.css
/js/bootstrap.min.js